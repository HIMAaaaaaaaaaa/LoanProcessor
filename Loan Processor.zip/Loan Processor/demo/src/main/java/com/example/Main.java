package com.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter credit score
        System.out.print("Enter credit score: ");
        int creditScore = scanner.nextInt();

        // Prompt the user to enter employment status
        System.out.print("Are you employed? (true/false): ");
        boolean isEmployed = scanner.nextBoolean();

        // Prompt the user to enter loan amount
        System.out.print("Enter loan amount: ");
        double loanAmount = scanner.nextDouble();

        // Create an instance of LoanProcessor
        LoanProcessor loanProcessor = new LoanProcessor();

        // Process the loan application
        String result = loanProcessor.processLoanApplication(creditScore, isEmployed, loanAmount);

        // Output the result
        System.out.println("Loan application result: " + result);

        // Close the scanner
        scanner.close();
    }
}
